import sys
import types

if "requests" not in sys.modules:
    sys.modules["requests"] = types.SimpleNamespace(get=lambda *args, **kwargs: None)

from types import SimpleNamespace

import pytest

from seq_llm.core.server_manager import ServerManager


class FakeProcess:
    def __init__(self, pid: int, exe: str = "", cmdline: list[str] | None = None, name: str = "proc"):
        self.pid = pid
        self._exe = exe
        self._cmdline = cmdline or []
        self._name = name

    def exe(self):
        return self._exe

    def cmdline(self):
        return self._cmdline

    def name(self):
        return self._name


def test_reclaim_port_kills_matching_llama_server(monkeypatch):
    manager = ServerManager()
    target_pid = 4321

    conn = SimpleNamespace(laddr=SimpleNamespace(port=8080), pid=target_pid)
    process = FakeProcess(
        pid=target_pid,
        exe="/usr/local/bin/llama-server",
        cmdline=["llama-server", "--port", "8080"],
        name="llama-server",
    )

    monkeypatch.setattr("seq_llm.core.server_manager.psutil.net_connections", lambda kind: [conn])
    monkeypatch.setattr("seq_llm.core.server_manager.psutil.Process", lambda pid: process)

    killed = []
    monkeypatch.setattr(manager, "_kill_process", lambda pid: killed.append(pid))

    manager._reclaim_port_processes(port=8080, strict=True)

    assert killed == [target_pid]


def test_reclaim_port_refuses_unrelated_process(monkeypatch):
    manager = ServerManager()
    target_pid = 8765

    conn = SimpleNamespace(laddr=SimpleNamespace(port=8080), pid=target_pid)
    process = FakeProcess(
        pid=target_pid,
        exe="/usr/bin/python3",
        cmdline=["python", "app.py"],
        name="python",
    )

    monkeypatch.setattr("seq_llm.core.server_manager.psutil.net_connections", lambda kind: [conn])
    monkeypatch.setattr("seq_llm.core.server_manager.psutil.Process", lambda pid: process)

    killed = []
    monkeypatch.setattr(manager, "_kill_process", lambda pid: killed.append(pid))

    with pytest.raises(RuntimeError, match="Refusing to terminate a non-llama process in strict mode"):
        manager._reclaim_port_processes(port=8080, strict=True)

    assert killed == []


def test_start_fails_cleanly_when_port_conflict_not_reclaimable(monkeypatch):
    manager = ServerManager()

    monkeypatch.setattr(manager, "_is_port_open", lambda host, port: True)
    monkeypatch.setattr(
        manager,
        "_reclaim_port_processes",
        lambda port, strict: (_ for _ in ()).throw(
            RuntimeError(
                "Port 8080 is in use by PID 9988 (python app.py). "
                "Refusing to terminate a non-llama process in strict mode."
            )
        ),
    )

    with pytest.raises(RuntimeError, match="Port 8080 is in use by PID 9988"):
        manager.start(model_path="model.gguf", port=8080)
